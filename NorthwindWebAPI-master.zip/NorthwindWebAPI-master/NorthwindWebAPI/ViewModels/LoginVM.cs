﻿
// Kullanılacak olan View için oluşturulan bir Model

namespace NorthwindWebAPI.ViewModels
{
    public class LoginVM
    {
        public string UserName { get; set; }
        public string UserPass { get; set; }
        public string CustomerId { get; set; }

    }
}
